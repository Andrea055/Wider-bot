import discord                                          #import libraries
from discord.ext import commands
from discord.ext.commands import bot
import asyncio
import datetime as dt
import uuid
import requests
import shutil
from requests import Response
from PIL import Image
import time
import os
import sys
import youtube_dl


response = requests.post(                               #inizialize removebg api
    'https://api.remove.bg/v1.0/removebg',
    files={'image_file': open('bg.png', 'rb')},
    data={'size': 'auto'},
    headers={'X-Api-Key': 'Vpu3vKEoDwgKzC9TzdiqgFTv'},
)
image_types = ["png", "jpeg", "gif", "jpg"]             #setting up parameters for wide
wpercent= 40
basewidth = 180
hsize = 50

client = commands.Bot(command_prefix="+")              #define bot prefix


@client.event                                           #message connect!
async def on_ready():
    print("Bot is ready")


@client.command()                                       # wide command and processing 
async def wide(ctx):

    try:
        url = ctx.message.attachments[0].url            # check for an image, call exception if none found
    except IndexError:
        print("Error: No attachments")
        await ctx.send("No attachments detected!")
    else:
        if url[0:26] == "https://cdn.discordapp.com":   # look to see if url is from discord
            r = requests.get(url, stream=True)
            imageName = 'fullsized_image' + '.png'      # save image to wide
            with open(imageName, 'wb') as out_file:
                print('Saving image: ' + imageName)
                shutil.copyfileobj(r.raw, out_file)     # save image from discord server
                img = Image.open('fullsized_image.png') 
                img = img.resize((460, 200), Image.ANTIALIAS)
                img.save('resized_image.png')           # save image wide
                await ctx.send('Wide!', file=discord.File('resized_image.png'))


@client.command()
async def remove(ctx):                                  # define removebg command
    try:
        url = ctx.message.attachments[0].url            # check for an image, call exception if none found
    except IndexError:
        print("Error: No attachments")                  # check attachments presence
        await ctx.send("No attachments detected!")
    else:
        if url[0:26] == "https://cdn.discordapp.com":   # look to see if url is from discord
            r = requests.get(url, stream=True)
            imageName = 'bg' + '.png'                   # save bg image
            with open(imageName, 'wb') as out_file:
                print('Saving image: ' + imageName)
                shutil.copyfileobj(r.raw, out_file)     # save image 
                
                   

        response = requests.post(                       # recall api to process image
    'https://api.remove.bg/v1.0/removebg',
    files={'image_file': open('bg.png', 'rb')},
    data={'size': 'auto'},
    headers={'X-Api-Key': 'Vpu3vKEoDwgKzC9TzdiqgFTv'},
)
    

    with open('no-bg.png', 'wb') as out:
        out.write(response.content)

                                                        # send image without background in discord server
    await ctx.send('No Backgroud!', file=discord.File('no-bg.png'))     


@client.command()
async def play(ctx, url : str):
    song_there = os.path.isfile("song.mp3")
    try:
        if song_there:
            os.remove("song.mp3")
    except PermissionError:
        await ctx.send("Wait for the current playing music to end or use the 'stop' command")
        return

    voiceChannel = discord.utils.get(ctx.guild.voice_channels, name='🌏Generale🌏')
    await voiceChannel.connect()
    voice = discord.utils.get(client.voice_clients, guild=ctx.guild)

    ydl_opts = {
        'format': 'bestaudio/best',
        'postprocessors': [{
            'key': 'FFmpegExtractAudio',
            'preferredcodec': 'mp3',
            'preferredquality': '192',
        }],
    }
    with youtube_dl.YoutubeDL(ydl_opts) as ydl:
        ydl.download([url])
    for file in os.listdir("./"):
        if file.endswith(".mp3"):
            os.rename(file, "song.mp3")
    voice.play(discord.FFmpegPCMAudio("song.mp3"))


@client.command()
async def leave(ctx):
    voice = discord.utils.get(client.voice_clients, guild=ctx.guild)
    if voice.is_connected():
        await voice.disconnect()
    else:
        await ctx.send("The bot is not connected to a voice channel.")


@client.command()
async def pause(ctx):
    voice = discord.utils.get(client.voice_clients, guild=ctx.guild)
    if voice.is_playing():
        voice.pause()
    else:
        await ctx.send("Currently no audio is playing.")


@client.command()
async def resume(ctx):
    voice = discord.utils.get(client.voice_clients, guild=ctx.guild)
    if voice.is_paused():
        voice.resume()
    else:
        await ctx.send("The audio is not paused.")


@client.command()
async def stop(ctx):
    voice = discord.utils.get(client.voice_clients, guild=ctx.guild)
    voice.stop()


client.run('ODM2Mjk1ODczOTE4NjY0NzI1.YIb7OQ.szkRpz8NuX6SOE_vSUnruxlo3jo')